package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.Teachers;
import com.example.demo.service.TeachersService;

@Controller
public class TeachersController {
    private TeachersService TeachersService;

    public TeachersController(TeachersService TeachersService) {
        super();
        this.TeachersService = TeachersService;
    }

    @GetMapping("/Teachers") 
    public String listTeachers(Model model) {
        model.addAttribute("Teachers", TeachersService.getAllTeachers());
        return "Teachers";
    }

    @GetMapping("/Teachers/new")
    public String createTeachersForm(Model model) {
        Teachers Teacher = new Teachers();
        model.addAttribute("Teachers", Teacher);
        return "create_Teachers";
    }

    @PostMapping("/Teachers")
    public String saveTeachers(@ModelAttribute("Teachers") Teachers Teacher) {
        TeachersService.saveTeachers(Teacher);
        return "redirect:/Teachers";
    }

    @GetMapping("/Teachers/edit/{idteacher}")
    public String editTeachersForm(@PathVariable Long idteacher, Model model) {
        model.addAttribute("Teachers", TeachersService.getTeachersById(idteacher));
        return "edit_Teachers";
    }

    @PostMapping("/Teachers/{idteacher}")
    public String updateTeachers(@PathVariable Long idteacher,
                                 @ModelAttribute("Teachers") Teachers Teacher,
                                 Model model) {
        Teachers existingTeacher = TeachersService.getTeachersById(idteacher);
        existingTeacher.setIdteacher(idteacher);
        existingTeacher.setName(Teacher.getName());
        existingTeacher.setAge(Teacher.getAge());
        existingTeacher.setDepartment(Teacher.getDepartment());
        TeachersService.updateTeachers(existingTeacher);
        return "redirect:/Teachers";
    }

    @GetMapping("/Teachers/{idteacher}")
    public String deleteTeachers(@PathVariable Long idteacher) {
        TeachersService.deleteTeachersById(idteacher);
        return "redirect:/Teachers";
    }
}

<?php
$db_server="localhost";
$db_user="root";
$db_pass="1234";
$db_name="proiect";

$conn=mysqli_connect($db_server,$db_user,$db_pass,$db_name);

if (isset($_GET['id'])) {
    $idteacher = $_GET['id'];

    $query = "SELECT * FROM teachers WHERE idteacher='$idteacher'";
    $result = mysqli_query($conn, $query);
    $teachers = mysqli_fetch_assoc($result);

    if (!$teachers) {
        echo "<div class='alert alert-danger'>Profesorul nu a fost găsită!</div>";
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $name = $_POST['name'];

    if (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        echo "<div class='alert alert-danger'>Numele poate conține doar litere și spații!</div>";
    } else {
    $age = $_POST['age'];
    $department = $_POST['department'];
    $salary = $_POST['salary'];

    $query = "UPDATE teachers SET name='$name', age='$age', department='$department',salary='$salary' WHERE idteacher='$idteacher'";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success'>Profesor actualizat cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger'>Eroare la actualizare: " . mysqli_error($conn) . "</div>";
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Teacher</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f0f0f0, #f8f9fa);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            border-radius: 10px 10px 0 0;
            background-color: #4CAF50;
            color: white;
        }
        .form-control {
            border-radius: 10px;
            padding: 10px;
        }
        .btn {
            border-radius: 25px;
            padding: 12px 20px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .alert {
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header text-center">
                        <h2>Edit Teacher</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="mb-3">
                                    <label class="form-label">Name</label>
                                    <input type="text" name="name" class="form-control" value="<?= $teachers['name'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Age</label>
                                    <input type="number" name="age" class="form-control" value="<?= $teachers['age'] ?>" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3">
                                    <label class="form-label">Department</label>
                                    <input type="text" name="department" class="form-control" value="<?= $teachers['department'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Salary</label>
                                    <input type="number" name="salary" class="form-control" value="<?= $teachers['salary'] ?>" required>
                                </div>

                            </div>

                            <div class="text-center">
                                <button type="submit" name="update" class="btn btn-primary w-50">Update Teacher</button>
                                <a href="index.php" class="btn btn-secondary w-50 mt-2">Back</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

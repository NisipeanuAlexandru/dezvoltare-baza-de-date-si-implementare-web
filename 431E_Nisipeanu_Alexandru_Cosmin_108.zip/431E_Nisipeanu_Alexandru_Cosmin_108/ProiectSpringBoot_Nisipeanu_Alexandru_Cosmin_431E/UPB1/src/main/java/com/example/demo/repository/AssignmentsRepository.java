package com.example.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.entity.Assignments;
public interface AssignmentsRepository extends
JpaRepository<Assignments, Long>{
}
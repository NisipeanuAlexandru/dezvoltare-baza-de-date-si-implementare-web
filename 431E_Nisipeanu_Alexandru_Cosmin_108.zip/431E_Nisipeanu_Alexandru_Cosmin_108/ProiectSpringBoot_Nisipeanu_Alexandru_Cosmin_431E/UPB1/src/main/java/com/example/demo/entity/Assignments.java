package com.example.demo.entity;
import jakarta.persistence.*;

@Entity
public class Assignments {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idassignment;

    @ManyToOne
    @JoinColumn(name = "idcourse", nullable = false)
    private Courses course;

    @ManyToOne
    @JoinColumn(name = "idteacher", nullable = false)
    private Teachers teacher;

    private String teachingtype;
    private String semester;
    private Integer allocatedhours;

  
    public Long getIdassignment() {
        return idassignment;
    }

    public void setIdassignment(Long idassignment) {
        this.idassignment = idassignment;
    }

    public Courses getCourse() {
        return course;
    }

    public void setCourse(Courses course) {
        this.course = course;
    }

    public Teachers getTeacher() {
        return teacher;
    }

    public void setTeacher(Teachers teacher) {
        this.teacher = teacher;
    }

    public String getTeachingtype() {
        return teachingtype;
    }

    public void setTeachingtype(String teachingtype) {
        this.teachingtype = teachingtype;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public Integer getAllocatedhours() {
        return allocatedhours;
    }

    public void setAllocatedhours(Integer allocatedhours) {
        this.allocatedhours = allocatedhours;
    }
}

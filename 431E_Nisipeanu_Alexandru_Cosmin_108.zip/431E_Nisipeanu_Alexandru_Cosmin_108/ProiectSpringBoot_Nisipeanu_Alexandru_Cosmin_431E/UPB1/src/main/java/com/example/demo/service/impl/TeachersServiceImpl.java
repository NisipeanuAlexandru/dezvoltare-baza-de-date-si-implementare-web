package com.example.demo.service.impl;
import java.util.List;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Teachers;
import com.example.demo.repository.TeachersRepository;
import com.example.demo.service.TeachersService;
@Service
public class TeachersServiceImpl implements TeachersService{
private TeachersRepository TeachersRepository;
public TeachersServiceImpl(TeachersRepository TeachersRepository)
{
super();
this.TeachersRepository = TeachersRepository;
}
@Override
public List<Teachers> getAllTeachers() {
return TeachersRepository.findAll();
}
@Override
public Teachers saveTeachers(Teachers Teachers) {
return TeachersRepository.save(Teachers);
}
@Override
public Teachers getTeachersById(Long idteacher) {
return TeachersRepository.findById(idteacher).get();
}
@Override
public Teachers updateTeachers(Teachers Teachers) {
return TeachersRepository.save(Teachers);
}
@Override
public void deleteTeachersById(Long idteacher) {
	TeachersRepository.deleteById(idteacher);
}
}
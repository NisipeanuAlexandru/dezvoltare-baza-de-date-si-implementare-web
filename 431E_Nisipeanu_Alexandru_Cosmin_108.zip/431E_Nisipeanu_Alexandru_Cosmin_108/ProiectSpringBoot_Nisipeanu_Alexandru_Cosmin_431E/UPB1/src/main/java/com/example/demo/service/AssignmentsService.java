package com.example.demo.service;
import java.util.List;

import com.example.demo.entity.Assignments;
public interface AssignmentsService {
List<Assignments> getAllAssignments();
Assignments saveAssignments(Assignments Assignments);
Assignments getAssignmentsById(Long idassignment);
Assignments updateAssignments(Assignments Assignments);
void deleteAssignmentsById(Long idassignment);
}
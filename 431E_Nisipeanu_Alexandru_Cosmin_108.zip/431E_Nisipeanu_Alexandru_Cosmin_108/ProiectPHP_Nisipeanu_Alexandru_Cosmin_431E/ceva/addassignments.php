<?php
$db_server = "localhost";
$db_user = "root";
$db_pass = "1234";
$db_name = "proiect";

$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

// Verificare conexiune
if (!$conn) {
    die("<div class='alert alert-danger'>Conexiunea la baza de date a eșuat: " . mysqli_connect_error() . "</div>");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create'])) {
    $teachingtype = mysqli_real_escape_string($conn, $_POST['teachingtype']);
    $semester = mysqli_real_escape_string($conn, $_POST['semester']);
    $allocatedhours = mysqli_real_escape_string($conn, $_POST['allocatedhours']);
    $idteacher = mysqli_real_escape_string($conn, $_POST['idteacher']);
    $idcourse = mysqli_real_escape_string($conn, $_POST['idcourse']);

    // Validare
    if (!preg_match("/^[0-9\s]+$/", $semester)) {
        echo "<div class='alert alert-danger'>Semestrul poate conține doar cifre!</div>";
    } elseif (!preg_match("/^[0-9\s]+$/", $allocatedhours)) {
        echo "<div class='alert alert-danger'>Orele alocate pot conține doar cifre!</div>";
    } else {
        // Inserare în baza de date
        $query = "INSERT INTO assignments (teachingtype, semester, allocatedhours, idteacher, idcourse) 
                  VALUES ('$teachingtype', '$semester', '$allocatedhours', '$idteacher', '$idcourse')";

        if (mysqli_query($conn, $query)) {
            echo "<div class='alert alert-success'>Assignment adăugat cu succes!</div>";
        } else {
            echo "<div class='alert alert-danger'>Eroare la adăugare: " . mysqli_error($conn) . "</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adaugă Assignment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #a1c4fd, #c2e9fb);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            border-radius: 10px 10px 0 0;
            background-color: #007bff;
            color: white;
        }
        .form-control, .form-select {
            border-radius: 10px;
            padding: 10px;
        }
        .btn {
            border-radius: 25px;
            padding: 12px 20px;
        }
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .alert {
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header text-center">
                        <h2>Adaugă Assignment</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label for="teachingtype" class="form-label">Teaching Type</label>
                                <input type="text" id="teachingtype" name="teachingtype" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="semester" class="form-label">Semester</label>
                                <input type="number" id="semester" name="semester" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="allocatedhours" class="form-label">Allocated Hours</label>
                                <input type="number" id="allocatedhours" name="allocatedhours" class="form-control" required>
                            </div>

                            <!-- Dropdown pentru profesori -->
                            <div class="mb-3">
                                <label for="idteacher" class="form-label">ID Teacher</label>
                                <select id="idteacher" name="idteacher" class="form-select" required>
                                    <option value="" disabled selected>-- Selectați un profesor --</option>
                                    <?php
                                    $teachers_query = "SELECT idteacher, name FROM teachers";
                                    $teachers_result = mysqli_query($conn, $teachers_query);

                                    if (mysqli_num_rows($teachers_result) > 0) {
                                        while ($teachers_row = mysqli_fetch_assoc($teachers_result)) {
                                            echo "<option value='{$teachers_row['idteacher']}'>{$teachers_row['name']}</option>";
                                        }
                                    } else {
                                        echo "<option disabled>Niciun profesor disponibil</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- Dropdown pentru cursuri -->
                            <div class="mb-3">
                                <label for="idcourse" class="form-label">ID Course</label>
                                <select id="idcourse" name="idcourse" class="form-select" required>
                                    <option value="" disabled selected>-- Selectați un curs --</option>
                                    <?php
                                    $course_query = "SELECT idcourse, name FROM courses";
                                    $course_result = mysqli_query($conn, $course_query);

                                    if (mysqli_num_rows($course_result) > 0) {
                                        while ($course_row = mysqli_fetch_assoc($course_result)) {
                                            echo "<option value='{$course_row['idcourse']}'>{$course_row['name']}</option>";
                                        }
                                    } else {
                                        echo "<option disabled>Niciun curs disponibil</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- Butoane -->
                            <div class="text-center mt-3 d-flex justify-content-between">
                                <a href="index.php" class="btn btn-secondary w-45">Back</a>
                                <button type="submit" name="create" class="btn btn-success w-45">Add Assignment</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

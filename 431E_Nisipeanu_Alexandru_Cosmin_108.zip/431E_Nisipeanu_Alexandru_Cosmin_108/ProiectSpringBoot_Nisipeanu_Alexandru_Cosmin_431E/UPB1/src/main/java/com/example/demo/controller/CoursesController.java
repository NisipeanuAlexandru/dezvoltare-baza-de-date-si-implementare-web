package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.Courses;
import com.example.demo.service.CoursesService;

@Controller
public class CoursesController {
    private CoursesService CoursesService;

    public CoursesController(CoursesService CoursesService) {
        super();
        this.CoursesService = CoursesService;
    }

    @GetMapping("/Courses")
    public String listCourses(Model model) {
        model.addAttribute("Courses", CoursesService.getAllCourses());
        return "Courses";
    }

    @GetMapping("/Courses/new")
    public String createCoursesForm(Model model) {
        Courses Course = new Courses();
        model.addAttribute("Courses", Course);
        return "create_Courses";
    }

    @PostMapping("/Courses")
    public String saveCourses(@ModelAttribute("Courses") Courses Course) {
        CoursesService.saveCourses(Course);
        return "redirect:/Courses";
    }

    @GetMapping("/Courses/edit/{idcourse}")
    public String editCoursesForm(@PathVariable Long idcourse, Model model) {
        model.addAttribute("Courses", CoursesService.getCoursesById(idcourse));
        return "edit_Courses";
    }

    @PostMapping("/Courses/{idcourse}")
    public String updateCourses(@PathVariable Long idcourse,
                                @ModelAttribute("Courses") Courses Course,
                                Model model) {
        Courses existingCourse = CoursesService.getCoursesById(idcourse);
        existingCourse.setIdcourse(idcourse);
        existingCourse.setName(Course.getName());
        existingCourse.setDuration(Course.getDuration());
        existingCourse.setCredits(Course.getCredits());

        CoursesService.updateCourses(existingCourse);
        return "redirect:/Courses";
    }

    @GetMapping("/Courses/{idcourse}")
    public String deleteCourses(@PathVariable Long idcourse) {
        CoursesService.deleteCoursesById(idcourse);
        return "redirect:/Courses";
    }
}

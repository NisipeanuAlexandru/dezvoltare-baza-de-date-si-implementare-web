<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(120deg, #84fab0, #8fd3f4);
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 1100px;
            margin-top: 50px;
        }
        .nav-tabs .nav-link {
            font-weight: bold;
            color: #333;
            border-radius: 8px 8px 0 0;
        }
        .nav-tabs .nav-link:hover {
            background: #17a2b8;
            color: white;
        }
        .nav-tabs .nav-link.active {
            background: #007bff;
            color: white;
        }
        .content-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            border: 2px solid #17a2b8;
        }
        h1 {
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">UPB</h1>
        <ul class="nav nav-tabs justify-content-center mt-4">
            <li class="nav-item">
                <a class="nav-link active" href="#courses" data-bs-toggle="tab">Courses</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#assignments" data-bs-toggle="tab">Assignments</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#teachers" data-bs-toggle="tab">Teachers</a>
            </li>
        </ul>

        <div class="tab-content mt-4">
            <div class="tab-pane fade show active" id="courses">
                <div class="content-card">
                    <h2>Courses</h2>
                    <?php include("courses.php"); ?>
                </div>
            </div>
            <div class="tab-pane fade" id="assignments">
                <div class="content-card">
                    <h2>Assignments</h2>
                    <?php include("assignments.php"); ?>
                </div>
            </div>
            <div class="tab-pane fade" id="teachers">
                <div class="content-card">
                    <h2>Teachers</h2>
                    <?php include("teachers.php"); ?>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

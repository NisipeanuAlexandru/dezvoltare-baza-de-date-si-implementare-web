<?php
$db_server="localhost";
$db_user="root";
$db_pass="1234";
$db_name="proiect";

$conn=mysqli_connect($db_server,$db_user,$db_pass,$db_name);

$idassignment = $_GET['id'];
$query = "SELECT * FROM assignments WHERE idassignment='$idassignment'";
$result = mysqli_query($conn, $query);
$assignments = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $teachingtype = mysqli_real_escape_string($conn, $_POST['teachingtype']);
    $semester = mysqli_real_escape_string($conn, $_POST['semester']);
    $allocatedhours = mysqli_real_escape_string($conn, $_POST['allocatedhours']);
    $idteacher = mysqli_real_escape_string($conn, $_POST['idteacher']);
    $idcourse = mysqli_real_escape_string($conn, $_POST['idcourse']);

    if (!preg_match("/^[0-9\s]+$/", $semester)) {
        echo "<div class='alert alert-danger'>Semestrul poate conține doar cifre!</div>";
    } elseif (!preg_match("/^[0-9\s]+$/", $allocatedhours)) {
        echo "<div class='alert alert-danger'>Orele alocate pot conține doar cifre!</div>";
    } else {
    $query = "UPDATE assignments 
              SET teachingtype='$teachingtype', semester='$semester', allocatedhours='$allocatedhours' WHERE idassignment='$idassignment'";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success'>Assignment actualizat cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger'>Eroare la actualizare: " . mysqli_error($conn) . "</div>";
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Assignment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f0f0f0, #f8f9fa);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            border-radius: 10px 10px 0 0;
            background-color: #007bff;
            color: white;
        }
        .form-control, .form-select {
            border-radius: 10px;
            padding: 10px;
        }
        .btn {
            border-radius: 25px;
            padding: 12px 20px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .alert {
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header text-center">
                        <h2>Edit Assignment</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="teachingtype" class="form-label">Teachingtype</label>
                                    <input type="text" id="teachingtype" name="teachingtype" class="form-control" value="<?= htmlspecialchars($assignments['teachingtype']) ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="semester" class="form-label">Semester</label>
                                    <input type="number" id="semester" name="semester" class="form-control" value="<?= htmlspecialchars($assignments['semester']) ?>" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="allocatedhours" class="form-label">Allocated Hours</label>
                                    <input type="text" id="allocatedhours" name="allocatedhours" class="form-control" value="<?= htmlspecialchars($assignments['allocatedhours']) ?>" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="idteacher" class="form-label">Teacher</label>
                                    <select id="idteacher" name="idteacher" class="form-select" required>
                                        <?php
                                        $teacher_query = "SELECT idteacher, name FROM teachers";
                                        $teacher_result = mysqli_query($conn, $teacher_query);

                                        while ($teacher_row = mysqli_fetch_assoc($teacher_result)) {
                                            $selected = $teacher_row['idteacher'] == $assignments['idteacher'] ? "selected" : "";
                                            echo "<option value='{$teacher_row['idteacher']}' $selected>{$teacher_row['name']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="idcourse" class="form-label">Course</label>
                                    <select id="idcourse" name="idcourse" class="form-select" required>
                                        <?php
                                        $course_query = "SELECT idcourse, name FROM courses";
                                        $course_result = mysqli_query($conn, $course_query);

                                        while ($course_row = mysqli_fetch_assoc($course_result)) {
                                            $selected = $course_row['idcourse'] == $assignments['idcourse'] ? "selected" : "";
                                            echo "<option value='{$course_row['idcourse']}' $selected>{$course_row['name']}</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="text-center">
                                <button type="submit" name="update" class="btn btn-primary w-50">Update Assignment</button>
                                <a href="index.php" class="btn btn-secondary w-50 mt-2">Back</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

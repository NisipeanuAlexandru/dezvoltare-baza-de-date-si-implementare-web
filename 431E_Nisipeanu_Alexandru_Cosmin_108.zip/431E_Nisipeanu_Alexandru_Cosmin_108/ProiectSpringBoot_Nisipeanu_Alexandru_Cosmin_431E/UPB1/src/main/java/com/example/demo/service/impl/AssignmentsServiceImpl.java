package com.example.demo.service.impl;
import java.util.List;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Assignments;
import com.example.demo.repository.AssignmentsRepository;
import com.example.demo.service.AssignmentsService;
@Service
public class AssignmentsServiceImpl implements
AssignmentsService{
private AssignmentsRepository AssignmentsRepository;
public AssignmentsServiceImpl(AssignmentsRepository
		AssignmentsRepository) {
super();
this.AssignmentsRepository = AssignmentsRepository;
}
@Override
public List<Assignments> getAllAssignments() {
return AssignmentsRepository.findAll();
}
@Override
public Assignments saveAssignments(Assignments
		Assignments) {
return AssignmentsRepository.save(Assignments);
}
@Override
public Assignments getAssignmentsById(Long idassignment)
{
return
		AssignmentsRepository.findById(idassignment).get();
}
@Override
public Assignments updateAssignments(Assignments
		Assignments) {
return AssignmentsRepository.save(Assignments);
}
@Override
public void deleteAssignmentsById(Long idassignment) {
	AssignmentsRepository.deleteById(idassignment);
}
}
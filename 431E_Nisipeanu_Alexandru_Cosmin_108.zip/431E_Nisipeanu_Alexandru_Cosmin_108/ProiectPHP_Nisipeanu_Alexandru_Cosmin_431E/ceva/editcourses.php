<?php
$db_server="localhost";
$db_user="root";
$db_pass="1234";
$db_name="proiect";

$conn=mysqli_connect($db_server,$db_user,$db_pass,$db_name);

if (isset($_GET['id'])) {
    $idcourse = $_GET['id'];

    $query = "SELECT * FROM courses WHERE idcourse='$idcourse'";
    $result = mysqli_query($conn, $query);
    $courses = mysqli_fetch_assoc($result);

    if (!$courses) {
        echo "<div class='alert alert-danger'>Cursul nu a fost găsită!</div>";
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $name = $_POST['name'];

    if (!preg_match("/^[a-zA-Z\s]+$/", $name)) {
        echo "<div class='alert alert-danger'>Numele poate conține doar litere și spații!</div>";
    } else {
    $duration = $_POST['duration'];
    $credits = $_POST['credits'];
    $courseformat = $_POST['courseformat'];

    $query = "UPDATE courses SET name='$name', duration='$duration', credits='$credits',courseformat='$courseformat' WHERE idcourse='$idcourse'";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success'>Curs actualizat cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger'>Eroare la actualizare: " . mysqli_error($conn) . "</div>";
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f0f0f0, #f8f9fa);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            border-radius: 10px 10px 0 0;
            background-color: #4CAF50;
            color: white;
        }
        .form-control {
            border-radius: 10px;
            padding: 10px;
        }
        .btn {
            border-radius: 25px;
            padding: 12px 20px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .alert {
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header text-center">
                        <h2>Edit Course</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="mb-3">
                                    <label class="form-label">Name</label>
                                    <input type="text" name="name" class="form-control" value="<?= $courses['name'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Duration</label>
                                    <input type="number" name="duration" class="form-control" value="<?= $courses['duration'] ?>" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="mb-3">
                                    <label class="form-label">Credits</label>
                                    <input type="number" name="credits" class="form-control" value="<?= $courses['credits'] ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Course Format</label>
                                    <input type="text" name="courseformat" class="form-control" value="<?= $courses['courseformat'] ?>" required>
                                </div>

                            </div>

                            <div class="text-center">
                                <button type="submit" name="update" class="btn btn-primary w-50">Update Course</button>
                                <a href="index.php" class="btn btn-secondary w-50 mt-2">Back</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

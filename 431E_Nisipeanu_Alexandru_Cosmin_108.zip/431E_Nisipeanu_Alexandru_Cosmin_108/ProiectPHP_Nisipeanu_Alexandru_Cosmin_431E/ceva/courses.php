<?php
$db_server = "localhost";
$db_user = "root";
$db_pass = "1234";
$db_name = "proiect";

$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
    $idcourse = $_POST['idcourse'] ?? null;

    $query = "DELETE FROM courses WHERE idcourse='$idcourse'";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success text-center'>Cursul a fost șters cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger text-center'>Eroare la ștergere: " . mysqli_error($conn) . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista Cursurilor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(120deg, #84fab0, #8fd3f4);
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
        }
        .table-container {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            border: 2px solid #17a2b8;
        }
        .table thead {
            background: #17a2b8;
            color: white;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
            border-radius: 8px;
            padding: 8px 15px;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="text-center mb-3">
        <h2 class="text-white">Lista Cursurilor</h2>
    </div>
    <div class="d-flex justify-content-end mb-3">
        <a href="addcourses.php" class="btn btn-success">Adaugă Curs</a>
    </div>
    <div class="table-container">
        <table class="table table-striped table-hover text-center">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nume</th>
                    <th>Durată</th>
                    <th>Credite</th>
                    <th>Format</th>
                    <th>Acțiuni</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT * FROM courses";
                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$row['idcourse']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['duration']}</td>
                            <td>{$row['credits']}</td>
                            <td>{$row['courseformat']}</td>
                            <td>
                                <div class='d-flex justify-content-center gap-2'>
                                    <a href='editcourses.php?id={$row['idcourse']}' class='btn btn-primary btn-sm'>Edit</a>
                                    <form method='POST'>
                                        <input type='hidden' name='idcourse' value='{$row['idcourse']}'>
                                        <button type='submit' name='delete' class='btn btn-danger btn-sm'>Șterge</button>
                                    </form>
                                </div>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>

<?php
$db_server = "localhost";
$db_user = "root";
$db_pass = "1234";
$db_name = "proiect";

$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete'])) {
    $idassignment = $_POST['idassignment'] ?? null;
    $query = "DELETE FROM assignments WHERE idassignment='$idassignment'";

    if (mysqli_query($conn, $query)) {
        echo "<div class='alert alert-success text-center'>Assignment șters cu succes!</div>";
    } else {
        echo "<div class='alert alert-danger text-center'>Eroare la ștergere: " . mysqli_error($conn) . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(120deg, #84fab0, #8fd3f4);
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
        }
        .table-container {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            border: 2px solid #17a2b8;
        }
        .table thead {
            background: #17a2b8;
            color: white;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="text-center mb-3">
        <h2 class="text-white">Lista Assignments</h2>
    </div>
    <div class="d-flex justify-content-end mb-3">
        <a href="addassignments.php" class="btn btn-success">Add Assignment</a>
    </div>
    <div class="table-container">
        <table class="table table-striped table-hover text-center">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Teachingtype</th>
                    <th>Semester</th>
                    <th>Allocatedhours</th>
                    <th>Teacher</th>
                    <th>Course</th>
                    <th>Acțiuni</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT a.idassignment, a.teachingtype, a.semester, a.allocatedhours, 
                                 t.name AS teacher_name, c.name AS course_name 
                          FROM assignments a
                          JOIN teachers t ON a.idteacher = t.idteacher
                          JOIN courses c ON a.idcourse = c.idcourse";

                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$row['idassignment']}</td>
                            <td>{$row['teachingtype']}</td>
                            <td>{$row['semester']}</td>
                            <td>{$row['allocatedhours']}</td>
                            <td>{$row['teacher_name']}</td>
                            <td>{$row['course_name']}</td>
                            <td>
                                <div class='d-flex justify-content-center gap-2'>
                                    <a href='editassignment.php?id={$row['idassignment']}' class='btn btn-primary btn-sm'>Edit</a>
                                    <form method='POST'>
                                        <input type='hidden' name='idassignment' value='{$row['idassignment']}'>
                                        <button type='submit' name='delete' class='btn btn-danger btn-sm'>Delete</button>
                                    </form>
                                </div>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>

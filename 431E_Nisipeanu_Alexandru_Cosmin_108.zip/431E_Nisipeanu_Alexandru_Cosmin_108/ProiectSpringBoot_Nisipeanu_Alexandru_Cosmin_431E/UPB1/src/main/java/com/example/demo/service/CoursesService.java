package com.example.demo.service;
import java.util.List;

import com.example.demo.entity.Courses;
public interface CoursesService {
List<Courses> getAllCourses();
Courses saveCourses(Courses Courses);
Courses getCoursesById(Long idcourse);
Courses updateCourses(Courses Courses);
void deleteCoursesById(Long idcourse);
}
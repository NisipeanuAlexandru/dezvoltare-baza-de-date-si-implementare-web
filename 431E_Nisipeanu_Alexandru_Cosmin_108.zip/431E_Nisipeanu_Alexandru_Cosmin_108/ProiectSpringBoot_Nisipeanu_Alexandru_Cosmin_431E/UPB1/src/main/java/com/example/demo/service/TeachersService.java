package com.example.demo.service;
import java.util.List;

import com.example.demo.entity.Teachers;
public interface TeachersService {
List<Teachers> getAllTeachers();
Teachers saveTeachers(Teachers Teachers);
Teachers getTeachersById(Long idteacher);
Teachers updateTeachers(Teachers Teachers);
void deleteTeachersById(Long idteacher);
}
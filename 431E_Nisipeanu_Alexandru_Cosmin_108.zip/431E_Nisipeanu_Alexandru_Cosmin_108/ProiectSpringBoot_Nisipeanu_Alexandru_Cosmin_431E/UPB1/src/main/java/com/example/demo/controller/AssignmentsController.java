package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Assignments;
import com.example.demo.service.AssignmentsService;
import com.example.demo.entity.Courses;
import com.example.demo.entity.Teachers;
import com.example.demo.repository.CoursesRepository;
import com.example.demo.repository.TeachersRepository;

@Controller
public class AssignmentsController {

    private final AssignmentsService assignmentsService;

    @Autowired
    private CoursesRepository coursesRepo;

    @Autowired
    private TeachersRepository teachersRepo;

    public AssignmentsController(AssignmentsService assignmentsService) {
        this.assignmentsService = assignmentsService;
    }

    @GetMapping("/Assignments")
    public String listAssignments(Model model) {
        model.addAttribute("assignments", assignmentsService.getAllAssignments());
        return "Assignments"; 
    }

    
    @GetMapping("/Assignments/new")
    public String createAssignmentsForm(Model model) {
        List<Courses> allCourses = coursesRepo.findAll();
        List<Teachers> allTeachers = teachersRepo.findAll();
        Assignments assignment = new Assignments();

        model.addAttribute("assignment", assignment);
        model.addAttribute("allCourses", allCourses);
        model.addAttribute("allTeachers", allTeachers);
        return "create_Assignments"; 
    }

    @PostMapping("/Assignments")
    public String saveAssignments(@ModelAttribute("assignment") Assignments assignment) {
        assignmentsService.saveAssignments(assignment);
        return "redirect:/Assignments";
    }


    @GetMapping("/Assignments/edit/{idassignment}")
    public String editAssignmentsForm(@PathVariable Long idassignment, Model model) {
        List<Courses> allCourses = coursesRepo.findAll();
        List<Teachers> allTeachers = teachersRepo.findAll();
        
        model.addAttribute("assignment", assignmentsService.getAssignmentsById(idassignment));
        model.addAttribute("allCourses", allCourses);
        model.addAttribute("allTeachers", allTeachers);
        return "edit_Assignments";
    }


    @PostMapping("/Assignments/{idassignment}")
    public String updateAssignments(
            @PathVariable Long idassignment,
            @ModelAttribute("assignment") Assignments assignment) {
        
        Assignments existingAssignment = assignmentsService.getAssignmentsById(idassignment);
        existingAssignment.setIdassignment(idassignment);
        existingAssignment.setCourse(assignment.getCourse());
        existingAssignment.setTeacher(assignment.getTeacher());
        existingAssignment.setTeachingtype(assignment.getTeachingtype());
        existingAssignment.setSemester(assignment.getSemester());
        existingAssignment.setAllocatedhours(assignment.getAllocatedhours());
        
        assignmentsService.updateAssignments(existingAssignment);
        return "redirect:/Assignments";
    }

    @GetMapping("/Assignments/{idassignment}")
    public String deleteAssignments(@PathVariable Long idassignment) {
        assignmentsService.deleteAssignmentsById(idassignment);
        return "redirect:/Assignments";
    }
}

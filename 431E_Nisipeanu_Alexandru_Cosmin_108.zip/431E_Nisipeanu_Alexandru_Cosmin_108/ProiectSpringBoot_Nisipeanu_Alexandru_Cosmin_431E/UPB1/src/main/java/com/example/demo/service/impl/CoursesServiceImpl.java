package com.example.demo.service.impl;
import java.util.List;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Courses;
import com.example.demo.repository.CoursesRepository;
import com.example.demo.service.CoursesService;
@Service
public class CoursesServiceImpl implements CoursesService{
private CoursesRepository CoursesRepository;
public CoursesServiceImpl(CoursesRepository CoursesRepository)
{
super();
this.CoursesRepository = CoursesRepository;
}
@Override
public List<Courses> getAllCourses() {
return CoursesRepository.findAll();
}
@Override
public Courses saveCourses(Courses Courses) {
return CoursesRepository.save(Courses);
}
@Override
public Courses getCoursesById(Long idcourse) {
return CoursesRepository.findById(idcourse).get();
}
@Override
public Courses updateCourses(Courses Courses) {
return CoursesRepository.save(Courses);
}
@Override
public void deleteCoursesById(Long idcourse) {
	CoursesRepository.deleteById(idcourse);
}
}
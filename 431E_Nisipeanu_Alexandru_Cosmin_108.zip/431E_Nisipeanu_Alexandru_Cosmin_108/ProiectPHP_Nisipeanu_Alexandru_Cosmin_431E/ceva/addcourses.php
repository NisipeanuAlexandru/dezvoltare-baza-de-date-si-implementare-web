<?php
$db_server = "localhost";
$db_user = "root";
$db_pass = "1234";
$db_name = "proiect";

$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create'])) {
    $name = $_POST['name'];
    $duration = $_POST['duration'];
    $credits = $_POST['credits'];
    $courseformat = $_POST['courseformat'];

    if (!preg_match("/^[a-zA-Z\s]+$/", $name)) 
        echo "<div class='alert alert-danger'>Numele cursului poate conține doar litere și spații!</div>";
    else if (!preg_match("/^[a-zA-Z-+\s]+$/", $courseformat))
        echo "<div class='alert alert-danger'>Formatul cursului poate conține doar litere și spații!</div>";
    else {
        $query = "INSERT INTO courses (name, duration, credits, courseformat) 
                  VALUES ('$name', '$duration', '$credits', '$courseformat')";

        if (mysqli_query($conn, $query)) {
            echo "<div class='alert alert-success'>Cursul adăugat cu succes!</div>";
        } else {
            echo "<div class='alert alert-danger'>Eroare la adăugare: " . mysqli_error($conn) . "</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adaugă Curs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #a1c4fd, #c2e9fb);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            border-radius: 10px 10px 0 0;
            background-color: #007bff;
            color: white;
        }
        .form-control, .form-select {
            border-radius: 10px;
            padding: 10px;
        }
        .btn {
            border-radius: 25px;
            padding: 12px 20px;
        }
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .alert {
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header text-center">
                        <h2>Adaugă Curs</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label">Nume Curs</label>
                                    <input type="text" id="name" name="name" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="duration" class="form-label">Durată</label>
                                    <input type="number" id="duration" name="duration" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="credits" class="form-label">Credite</label>
                                    <input type="number" id="credits" name="credits" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="courseformat" class="form-label">Format Curs</label>
                                    <input type="text" id="courseformat" name="courseformat" class="form-control" required>
                                </div>
                            </div>

                            <!-- Butoane -->
                            <div class="text-center mt-3 d-flex justify-content-between">
                                <a href="index.php" class="btn btn-secondary w-45">Back</a>
                                <button type="submit" name="create" class="btn btn-success w-45">Adaugă Curs</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

package com.example.demo.entity;
import jakarta.persistence.*;
@Entity
@Table(name = "teachers")
public class Teachers {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long idteacher;
@Column(name = "name", nullable = false)
private String name;
@Column(name = "age")
private Long age;
@Column(name = "department")
private String department;
@Column(name = "salary")
private Long salary;
public Teachers() {
}

public Teachers(String name, Long age, String department, Long salary) {
super();
this.name = name;
this.age = age;
this.department = department;
this.salary = salary;
}

public Long getIdteacher() {
return idteacher;
}
public void setIdteacher(Long idteacher) {
this.idteacher = idteacher;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public Long getAge() {
return age;
}
public void setAge(Long age) {
this.age = age;
}
public String getDepartment() {
return department;
}
public void setDepartment(String department) {
this.department = department;
}
public Long getSalary() {
return salary;
}
public void setSalary(Long salary) {
this.salary =salary;
}
}
package com.example.demo.entity;
import jakarta.persistence.*;
@Entity
@Table(name = "courses")
public class Courses {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long idcourse;
@Column(name = "name", nullable = false)
private String name;
@Column(name = "duration")
private Long duration;
@Column(name = "credits")
private Long credits;
@Column(name = "courseformat")
private String courseformat;
public Courses() {
}
public Courses(String name, Long duration, Long credits, String courseformat) {
super();
this.name = name;
this.duration = duration;
this.credits = credits;
this.courseformat =courseformat ;
}
public Long getIdcourse() {
return idcourse;
}
public void setIdcourse(Long idcourse) {
this.idcourse = idcourse;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public Long getDuration() {
return duration;
}
public void setDuration(Long duration) {
this.duration = duration;
}
public Long getCredits() {
return credits;
}
public void setCredits(Long credits) {
this.credits = credits;
}
public String getCourseformat() {
return courseformat;
}
public void setCourseformat(String courseformat) {
this.courseformat = courseformat;
}
}